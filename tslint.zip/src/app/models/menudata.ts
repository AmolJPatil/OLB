import { Menu, SubMenu } from "./menu"


export let menuData:Menu[]=[
    new Menu('Account Summary', '', '',[new SubMenu('Transactions', '', '')]),
    new Menu('Request', '','', [new SubMenu('Cheque Request', '',''), new SubMenu('Address Change','','')]),
    new Menu('Fund Transfer', '','', [new SubMenu('NEFT', '',''), new SubMenu('RTGS','',''), new SubMenu('IMPS','','')])

];

