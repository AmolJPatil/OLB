import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private _token: string;
  private _isLoggedIn: boolean;
  
  constructor() { }


  public get isLoggedIn(): boolean {
    if(this.token!=null)
      this._isLoggedIn = true;

    return this._isLoggedIn;
  }

  public set isLoggedIn(value: boolean) {
    this._isLoggedIn = value;
  }

  public get token(): string {
    return this._token;
  }
  public set token(value: string) {
    this._token = value;
    window.sessionStorage.setItem("token", this._token);
  }

  logout()
  {
    window.sessionStorage.removeItem("token");
  }

}
